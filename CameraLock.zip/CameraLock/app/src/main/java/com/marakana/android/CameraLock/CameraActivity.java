package com.marakana.android.devicepolicydemo;

import android.app.Activity;

public class CameraActivity extends Activity {

}
